<div class="container">
	<div id="lienzo">
		<div class="card text-center filosofia-bg">
			<div class="card-header">
				<img src="img/saitologo.png" style="height:80px; width:80px" alt="">
			</div>
			<h1 class="card-title">Filosofía</h1>
			<div class="card-body">
				<p class="card-text">Preservamos y compartimos la gran influencia de mi Padre Saito Morihiro, mientras permanecemos fieles a la herencia t&eacute;cnica y espiritual que nos leg&oacute; el fundador Morihei Ueshiba.<br>
					Intentamos continuamente mejorarnos con la pr&aacute;tica intensiva y sistem&aacute;tica del kihon, y creemos que cada sesi&oacute;n de entrenamiento es una oportunidad &uacute;nica de sentirnos m&aacute;s cercanos al fundador.
					En primer lugar, aplico este entrenamiento permanente a mi mismo.</p>

			</div>
			<div class="card-footer text-muted">
				Hitohira Saito Sensei
			</div>
		</div>

	</div>
</div>