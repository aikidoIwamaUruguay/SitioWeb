<div id="seminario">
	<div class="tituloSeminario">
		<div class="close"><a onclick="cerrarDivSeminario('none')">(Cerrar)</a></div>
		
		<span class="tit1">SEMINARIO INTERNACIONAL</span><br>
		<span class="tit11">SHIHAN ALESSANDRO TITTARELLI - 7&#176; DAN</span><br>
		
		<div id="contenidoSem">
			<div id="sabado">
				<span class="tit2">S&Aacute;BADO 14 DE SEPTIEMBRE</span><br>
				<span class="tit2">Acevedo D&iacute;az 1084 (MontevideoAikido)</span><br><br>
				<div id="mapSabado">
					<iframe width="300" height="300" src="https://www.google.com/maps/ms?msa=0&amp;msid=206440040874059425072.0004e5fe58aada62e7d77&amp;ie=UTF8&amp;t=m&amp;ll=-34.908088,-56.166959&amp;spn=0.005279,0.006437&amp;z=16&amp;output=embed"></iframe><br>
					<small>Ver <a href="https://www.google.com/maps/ms?msa=0&amp;msid=206440040874059425072.0004e5fe58aada62e7d77&amp;ie=UTF8&amp;t=m&amp;ll=-34.908088,-56.166959&amp;spn=0.005279,0.006437&amp;z=16&amp;source=embed" style="color:#0000FF;text-align:left" target="blank">Montevideo Aikido</a> en un mapa m&aacute;s grande</small>
				</div>
				<span class="tit3">
					HORARIOS<br>
					S&Aacute;BADO 14<br><br>
					KEIKO 1 - 8:00 a 9:15<br> 
					KEIKO 2 - 9:15 a 10:30<br>
					KEIKO 3 - 10:45 a 12:00<br>
					Foto grupal - 12:05<br>
					Tiempo libre para almuerzo<br>
					KEIKO 4 - 15:00 a 16:15<br>
					KEIKO 5 - 16:15 a 17:30<br>
					KEIKO 6 - 17:30 a 18:45<br><br>
					Cena de Cofraternizaci&oacute;n<br>  
					21:00 hs&nbsp;&nbsp;Club<br>
					Residentes de R&iacute;o Negro<br>
					Canelones 2327<br>
					esquina Br. Artigas
				</span>				
			</div>
			<div id="domingo">
				<span class="tit2">DOMINGO 15 DE SEPTIEMBRE</span><br>
				<span class="tit2">Camacu&aacute; 623 (Club Hebraica)</span><br><br>
				<div id="mapDomingo">
					<iframe width="300" height="300" src="https://www.google.com/maps/ms?msa=0&amp;msid=206440040874059425072.0004e5fec68ddd249e96f&amp;ie=UTF8&amp;t=m&amp;ll=-34.909478,-56.201034&amp;spn=0.005279,0.006437&amp;z=16&amp;output=embed"></iframe><br>
					<small>Ver <a href="https://www.google.com/maps/ms?msa=0&amp;msid=206440040874059425072.0004e5fec68ddd249e96f&amp;ie=UTF8&amp;t=m&amp;ll=-34.909478,-56.201034&amp;spn=0.005279,0.006437&amp;z=16&amp;source=embed" style="color:#0000FF;text-align:left" target="blank">Club Hebraica</a> en un mapa m&aacute;s grande</small>
				</div>
				<span class="tit3">
					HORARIOS<br>
					DOMINGO 15<br><br>
					KEIKO 7 - 9:00 a 10:15<br> 
					KEIKO 8 - 10:15 a 11:30<br>
					KEIKO 9 - 11:30 a 12:45<br>
					Foto grupal - 12:05
				</span>					
			</div>			
		</div>
		<span class="tit3">Favor traer tanto, jo y boken</span><br><br>
		<span class="tit3">INSCRIPCI&Oacute;N: U$D 150 (CIENTO CINCUENTA D&Oacute;LARES AMERICANOS)</span><br>
		<span class="tit3">B.R.O.U. Caja de Ahorro US$ n&#176; 179-1665001</span><br><br>
		<span class="tit33">ABIERTO A TODAS LAS ESCUELAS Y ESTILOS!!!</span><br>
		<span class="tit3">INFO: AIKISHURENKAIURUGUAY@GMAIL.COM</span>
	</div>
</div>
