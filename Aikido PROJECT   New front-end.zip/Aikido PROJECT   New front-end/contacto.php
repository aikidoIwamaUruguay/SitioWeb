<div class="container">

	<div id="lienzo">

		<div class="row">
			<div class="col-sm-1 col-md-2 "></div>
			<div class="col-sm-10 col-md-8 ">
				<form action="index.php?pag=contacto" method="post" onsubmit="return validar(this);">

					<div class="form-group">
						<label for="exampleFormControlInput1">Nombre</label>
						<input type="text" name="nombre" class="form-control" id="exampleFormControlInput1" placeholder="Escriba su nombre...">
					</div>
					<div class="form-group">
						<label for="exampleFormControlInput1">e-mail</label>
						<input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Escriba su correo electrónico...">
					</div>
					<div class="form-group">
						<label for="exampleFormControlInput1">Asunto</label>
						<input type="text" name="asunto" class="form-control" id="exampleFormControlInput1" placeholder="Describa el asunto... ">
					</div>


					<div class="form-group">
						<label for="exampleFormControlTextarea1">Mensaje</label>
						<textarea name="mensaje" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
					</div>

					<button type="submit" value="Enviar" name="enviar" class="btn btn-primary" style="text-align:right;">Enviar</button>
				</form>


			</div>
			<div class="col-sm-1 col-md-2 "></div>
		</div>



		<!-- form original -->

		<!-- <div class="infoContacto">
			<h1 style="text-align:center;">Contacto</h1>

			<div id="contacto">
				<form action="index.php?pag=contacto" method="post" onsubmit="return validar(this);">
					<table>
						<tr>
							<td>Nombre</td>
							<td><input type="text" name="nombre"></td>
						</tr>
						<tr>
							<td>Email</td>
							<td><input type="text" name="email"></td>
						</tr>
						<tr>
							<td>Asunto</td>
							<td><input type="text" name="asunto" ></td>
						</tr>
						<tr>
							<td>Mensaje</td>
							<td><textArea name="mensaje"></textArea></td>
						</tr>
						<tr>
							<td colspan="2"><input type="submit" value="Enviar" name="enviar" id="botones" /></td>
						</tr>
					</table>
				</form> -->

		<?php
		if (isset($_POST['enviar'])) {
			$mail_to = 'aikidoiwamauruguay@gmail.com';
			$asunto  = $_POST['asunto'];
			$mensaje = "Nombre: " . $_POST['nombre'] . "\n Asunto: " . stripcslashes($_POST['asunto']) . "\n Mensaje:\n " . stripcslashes($_POST['mensaje']);
			$headers = "From: " . $_POST['email'] . "\r\n" .
				"Reply-To: " . $_POST['email'] . "\r\n" .
				'X-Mailer: PHP/' . phpversion();

			//bool mail ( string $to , string $subject , string $message [, string $additional_headers [, string $additional_parameters ]] )	
			if (mail($mail_to, $asunto, $mensaje, $headers))
				echo '<strong style="color: #08c;">Su mensaje ha sido enviado correctamente.<br>Gracias por ponerse en contacto.</strong>';
			else
				echo '<strong style="color: red;">Error al enviar el formulario.<br>Por favor, int&eacute;nte de nuevo m&aacute;s tarde.</strong>';
		}
		?>

	</div>
</div>
</div>
</div>