<div class="container">
	<div class="info">

		<h1>Fotos</h1>
		<ul>
			<li><a href="#" onClick="verFotos('misc')">Miscel&aacute;nea</a></li>
			<li><a href="#" onClick="verFotos('seminarioChile')">2013 - Chile, Seminario internacional: <b>Sensei Hitohira Saito</b></a></li>
			<li><a href="#" onClick="verFotos('seminarioTitt')">2013 - Montevideo, Seminario internacional: <b>Shihan Alessandro Tittarelli</b></a></li>
			<li><a href="#" onClick="verFotos('seminarioMald')">2013 - Maldonado, 1er Encuentro de Budo tradicional Japon&eacute;s</a></li>
			<li><a href="#" onClick="verFotos('seminarioMont')">2012 - Montevideo, Seminario internacional: <b>Sensei Hitohira Saito</b></a></li>
		</ul>
	</div>

	<div class="info">
		<h1>Videos</h1>

		<h2>Hitohira Saito</h2>
		<ul>
			<li><a href="#" onClick="verFotos('hs-suburi')">Suburis</a></li>
			<li><a href="#" onClick="verFotos('hs-kata31')">31 Jo Kata</a></li>
		</ul>

		<h2>Morihiro Saito</h2>
		<ul>
			<li><a href="#" onClick="verFotos('ken7')">7 ken suburi</a></li>
			<li><a href="#" onClick="verFotos('kumiTachi123')">1-2-3 Kumi Tachi</a></li>
			<li><a href="#" onClick="verFotos('jo20')">20 Jo suburi</a></li>
			<li><a href="#" onClick="verFotos('cata31')">31 Jo Kata</a></li>
			<li><a href="#" onClick="verFotos('cata13')">13 Jo Kata</a></li>
			<li><a href="#" onClick="verFotos('kumiJo1-5')">1-5 Kumi Jo</a></li>
			<li><a href="#" onClick="verFotos('kumiJo6-10')">6-10 Kumi Jo</a></li>
		</ul>


	</div>
</div>