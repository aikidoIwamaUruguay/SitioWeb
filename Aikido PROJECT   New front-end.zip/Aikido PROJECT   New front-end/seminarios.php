<!-- <div class="inicio"> -->
<!-- 	<div class="foto"> -->
<!-- 		<img src="img/inicio/encuentroBudo.jpg" border="0"/> -->
<!-- 	</div> -->
<!-- </div> -->
<!-- <div class="inicio"> -->
<!--<div class="texto" style="text-align: center;"> -->
<!-- 		<h1>2&#170; Clase Abierta: Fundamentos del Aikido</h1> -->
<!-- 		<h2>Club Hebarica 27de junio 20 hrs</h2> -->
<!-- 		<h1>Sensei Mario Silva 5&#176; Dan</h1> -->
<!-- 	</div>	 -->
<!-- </div> -->
<!-- <div class="inicio"> -->
<!-- 	<div class="foto"> -->
<!-- 		<img src="img/inicio/bukiWazaAgo13.jpg" border="0"/> -->
<!-- 	</div> -->
<!-- </div> -->


<!-- <div class="inicio"> -->
<!-- 	<div class="foto"> -->
<!-- 		<img src="img/inicio/keikoVramian.jpg"/> -->
<!-- 	</div> -->
<!-- </div> -->

<!-- <div class="inicio"> -->
<!--	<p class="cartel">En setiembre comienzan las clases en horario matutino en el club <strong style="color:white;">Vramian</strong>,<br>los esperamos.</p> -->
<!-- </div> -->


<!-- <div class="inicio"> -->
<!-- 	<div class="foto"> -->
<!-- 		<img src="img/inicio/brindis690-2015_1.jpg"/> -->
<!-- 	</div> -->
<!-- </div> -->

<div class="container">
	<!-- GRAN FOTO NOVEDADES -->
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<img src="img/inicio/seminario2019sensei.jpg">
		</div>
		<div class="col-md-2"></div>
	</div>
	<!-- 1er fila -->
	<div class="row">
		<div class="col-md-4">

			<div class="foto">
				<img src="img/inicio/entrenamiento2.png">
			</div>
		</div>
		<div class="class col-md-4">
			<div class="foto">
				<a href="index.php?pag=info"><img src="img/inicio/festejo20anios.jpg" /></a>
			</div>
		</div>

		<!-- 	<center> -->
		<!-- 		<h2>Es necesario el registro previo para el ingreso al seminario</h2> -->
		<!-- 		Comunicarse a trav&eacute;s de nuestra p&aacute;gina de contacto. -->
		<!-- 	</center> -->
		<div class="col-md-4">
			<div class="foto">
				<img src="img/inicio/seminarioMitsuyoshiSaitoHebraica.jpg">
			</div>
		</div>
	</div>
	<!-- fin 1er fila -->
	<!-- 2da fila -->
	<div class="row">
		<div class="col-md-4">
			<div class="foto">
				<img src="img/inicio/mitsuyoshiBrasil2016.jpg" />
			</div>
		</div>
		<div class="col-md-4">
			<div class="foto">
				<a href="index.php?pag=info"><img src="img/inicio/seminario2015.jpg" /></a>
			</div>
		</div>



		<!-- <div class="inicio"> -->
		<!-- 	<div class="foto"> -->
		<!-- 		<a href="index.php?pag=info"><img src="img/inicio/seminario2015Horarios.jpg"/></a> -->
		<!-- 	</div> -->
		<!-- </div> -->
		<div class="col-md-4">
			<div class="foto">
				<a href="index.php?pag=info"><img src="img/inicio/koshukaiInternacional.jpg"></a>
			</div>
		</div>
	</div>
	<!-- fin 2da fila -->


	<div class="row">
		<div class="col-md-4">

			<div class="foto">
				<a href="index.php?pag=info"><img src="img/inicio/2014-07-10-keiko.jpg" /></a>
			</div>
		</div>
		<div class="col-md-4">

			<div class="foto">
				<a href="index.php?pag=info"><img src="img/inicio/aniversario.jpg" style="width: 300px" /></a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="foto">
				<img src="img/inicio/seminarioSanPablo.jpg" />
			</div>
		</div>

	</div>
	<div class="row">
		<div class="col-md-4">

			<div class="foto">
				<img src="img/inicio/seminarioChile.jpg" />
			</div>
		</div>
		<div class="col-md-4">

			<div class="foto">
				<a onclick="cerrarDivSeminario('')"><img src="img/inicio/seminarioTittarelli.jpg" style="cursor: pointer;" /></a>
			</div>
		</div>
		<div class="col-md-4">
			<p class="texto">
				<h5>Primer seminario de Aikido tradicional ISSASK en Montevideo</h5>
				<h6>12 al 14 de Octubre de 2012</h6>
			</p>
			<div class="foto">
				<img src="img/inicio/seminarioMontevideo.jpg" />
			</div>
		</div>

	</div>

</div>