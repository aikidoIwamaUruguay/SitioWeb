<div class="container">
	<div class="card-deck">
		<div class="card" style="height:25rem;">
			<img src="img/mario.jpg" class="card-img-top instructores instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Mario Silva</h5>
				<p class="card-text"><small class="text-muted">5to. DAN</small></p>
			</div>
		</div>
		<div class="card" style="height:25rem;">
			<img src="img/gustavo.jpg" class="card-img-top instructores instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Gustavo Olivera</h5>
				<p class="card-text"><small class="text-muted">3er. DAN</small></p>
			</div>
		</div>
		<div class="card" style="height:25rem;">
			<img src="img/ale.jpg" class="card-img-top instructores instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Alejandro Monteiro</h5>
				<p class="card-text"><small class="text-muted">3er. DAN</small></p>
			</div>
		</div>
	</div>
	<div class="card-deck">
		<div class="card" style="height:25rem;">
			<img src="" class="card-img-top instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Aldo Villagra</h5>
				<p class="card-text"><small class="text-muted">2do. DAN</small></p>
			</div>
		</div>
		<div class="card" style="height:25rem;">
			<img src="img/marcello.jpg" class="card-img-top instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Marcelo Scarpa</h5>
				<p class="card-text"><small class="text-muted">2do. DAN</small></p>
			</div>
		</div>
		<div class="card" style="height:25rem;">
			<img src="img/sancho.jpg" class="card-img-top instructores instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Daniel Sancho</h5>
				<p class="card-text"><small class="text-muted">1er. DAN</small></p>
			</div>
		</div>
	</div>
	<div class="card-deck">
		<div class="card" style="height:25rem;">
			<img src="" class="card-img-top instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Edward Lavie</h5>
				<p class="card-text"><small class="text-muted">1er. DAN</small></p>
			</div>
		</div>



		<div class="card" style="height:25rem;">
			<img src="" class="card-img-top instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">Jorge Ribeiro da Costa</h5>
				<p class="card-text"><small class="text-muted">1er. DAN</small></p>
			</div>
		</div>

		<div class="card" style="height:25rem;">
			<img src="" class="card-img-top instructores" alt="...">
			<div class="card-body">
				<h5 class="card-title">José Millán</h5>
				<p class="card-text"><small class="text-muted">1er. DAN</small></p>
			</div>
		</div>
	</div>
</div>